package modelo;

/**
 * Entidad que representa a un visitante identificado por su brazalete.
 *
 * @author Equipo UTP Park Manager
 */
public class Visitante {

    private int codigoBrazalete;
    private String nombre;
    private String tipoPase;
    private double saldo;

    //Constructor vacio necesario para la persistencia XML
    public Visitante() {
        this.codigoBrazalete = 0;
        this.nombre = "";
        this.tipoPase = "Regular";
        this.saldo = 0.0;
    }

    //Constructor que recibe todos los datos del visitante
    public Visitante(int codigoBrazalete, String nombre, String tipoPase, double saldo) {
        this.codigoBrazalete = codigoBrazalete;
        this.nombre = nombre;
        this.tipoPase = tipoPase;
        this.saldo = saldo;
    }

    public int getCodigoBrazalete() {
        return codigoBrazalete;
    }

    public void setCodigoBrazalete(int codigoBrazalete) {
        this.codigoBrazalete = codigoBrazalete;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoPase() {
        return tipoPase;
    }

    public void setTipoPase(String tipoPase) {
        this.tipoPase = tipoPase;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    //Aumenta el saldo del brazalete
    public void recargarSaldo(double monto) {
        this.saldo = this.saldo + monto;
    }

    //Descuenta una compra si el visitante tiene saldo suficiente
    public boolean descontarSaldo(double monto) {
        if (monto <= 0 || monto > saldo) {
            return false;
        }
        saldo = saldo - monto;
        return true;
    }

    //Devuelve VIP 3, FastPass 2 y regular 1
    public int obtenerPrioridad() {
        if (tipoPase == null) {
            return 1;
        }

        switch (tipoPase.toLowerCase().trim()) {
            case "vip":
                return 3;
            case "fastpass":
                return 2;
            default:
                return 1;
        }
    }

    @Override
    //Devuelve los datos del visitante en formato de texto
    public String toString() {
        StringBuilder resultado = new StringBuilder();
        resultado.append("-----------------------------------");
        resultado.append("\nDATOS DEL VISITANTE");
        resultado.append("\n-----------------------------------");
        resultado.append("\nCódigo del brazalete: ").append(codigoBrazalete);
        resultado.append("\nNombre              : ").append(nombre);
        resultado.append("\nTipo de pase        : ").append(tipoPase);
        resultado.append("\nSaldo               : S/ ").append(String.format("%.2f", saldo));
        return resultado.toString();
    }
}
