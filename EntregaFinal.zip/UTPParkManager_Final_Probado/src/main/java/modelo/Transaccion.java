package modelo;

/**
 * Entidad que representa una compra o recarga realizada con un brazalete.
 *
 * @author Equipo UTP Park Manager
 */
public class Transaccion {

    private int codigo;
    private int codigoBrazalete;
    private String tipo;
    private double monto;
    private String fecha;
    private String descripcion;

    //Constructor vacio necesario para la persistencia XML
    public Transaccion() {
        this.codigo = 0;
        this.codigoBrazalete = 0;
        this.tipo = "";
        this.monto = 0.0;
        this.fecha = "";
        this.descripcion = "";
    }

    //Constructor que recibe los datos de la transaccion
    public Transaccion(int codigo, int codigoBrazalete, String tipo,
                       double monto, String fecha, String descripcion) {
        this.codigo = codigo;
        this.codigoBrazalete = codigoBrazalete;
        this.tipo = tipo;
        this.monto = monto;
        this.fecha = fecha;
        this.descripcion = descripcion;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigoBrazalete() {
        return codigoBrazalete;
    }

    public void setCodigoBrazalete(int codigoBrazalete) {
        this.codigoBrazalete = codigoBrazalete;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    //Devuelve los datos de la transaccion en formato de texto
    public String toString() {
        return codigo + " - Brazalete " + codigoBrazalete + " - "
                + tipo + " - S/ " + String.format("%.2f", monto)
                + " - " + fecha + " - " + descripcion;
    }
}
