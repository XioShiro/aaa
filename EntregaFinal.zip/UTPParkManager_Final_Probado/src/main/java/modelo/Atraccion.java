package modelo;

import estructura.ColaPrioridad;
import estructura.ListaCircular;
import estructura.ListaDoble;

/**
 * Entidad que agrupa las estructuras usadas por una atracción.
 *
 * @author Equipo UTP Park Manager
 */
public class Atraccion {

    private String nombre;
    private int capacidadVagones;
    private ListaDoble filaVirtual;
    private ListaCircular cicloVagones;
    private ColaPrioridad colaAccesoFisico;

    //Constructor vacio necesario para guardar y cargar el XML
    public Atraccion() {
        this.nombre = "";
        this.capacidadVagones = 0;
        this.filaVirtual = new ListaDoble();
        this.cicloVagones = new ListaCircular();
        this.colaAccesoFisico = new ColaPrioridad();
    }

    //Constructor que inicializa la atraccion y sus tres estructuras
    public Atraccion(String nombre, int capacidadVagones) {
        this();
        this.nombre = nombre;
        this.capacidadVagones = capacidadVagones;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidadVagones() {
        return capacidadVagones;
    }

    public void setCapacidadVagones(int capacidadVagones) {
        this.capacidadVagones = capacidadVagones;
    }

    public ListaDoble getFilaVirtual() {
        return filaVirtual;
    }

    public void setFilaVirtual(ListaDoble filaVirtual) {
        this.filaVirtual = filaVirtual == null ? new ListaDoble() : filaVirtual;
    }

    public ListaCircular getCicloVagones() {
        return cicloVagones;
    }

    public void setCicloVagones(ListaCircular cicloVagones) {
        this.cicloVagones = cicloVagones == null ? new ListaCircular() : cicloVagones;
    }

    public ColaPrioridad getColaAccesoFisico() {
        return colaAccesoFisico;
    }

    public void setColaAccesoFisico(ColaPrioridad colaAccesoFisico) {
        this.colaAccesoFisico = colaAccesoFisico == null ? new ColaPrioridad() : colaAccesoFisico;
    }
}
