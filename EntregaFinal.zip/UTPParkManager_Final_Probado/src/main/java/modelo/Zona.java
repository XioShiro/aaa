package modelo;

/**
 * Entidad del mapa temático del parque.
 *
 * @author Equipo UTP Park Manager
 */
public class Zona {

    private int codigo;
    private String nombre;
    private String descripcion;

    //Constructor vacio necesario para la persistencia XML
    public Zona() {
        this.codigo = 0;
        this.nombre = "";
        this.descripcion = "";
    }

    //Constructor que recibe todos los datos de la zona
    public Zona(int codigo, String nombre, String descripcion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    //Devuelve los datos de la zona en una cadena
    public String toString() {
        return codigo + " - " + nombre + " - " + descripcion;
    }
}
