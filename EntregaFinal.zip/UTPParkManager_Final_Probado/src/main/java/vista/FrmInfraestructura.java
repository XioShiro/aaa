/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import conexionxml.XMLManager;
import estructura.ArbolABB;
import estructura.NodoABB;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Zona;

/**
 * Formulario del módulo de infraestructura.
 * Organiza las zonas del parque mediante un árbol binario de búsqueda.
 *
 * @author Equipo UTP Park Manager
 */
public class FrmInfraestructura extends javax.swing.JFrame {

    private static final String ARCHIVO_XML = "zonas.xml";
    private ArbolABB arbol;
    private DefaultTableModel modeloTabla;

    //Constructor del formulario de infraestructura
    public FrmInfraestructura() {
        initComponents();
        cargarDatos();
        prepararTabla();
        llenarTabla();
        this.setLocationRelativeTo(null);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                guardarDatos();
            }
        });
    }

    //Prepara la tabla para mostrar las zonas del árbol ABB
    private void prepararTabla() {
        modeloTabla = new DefaultTableModel(
                new String[]{"Código", "Nombre", "Descripción"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblZonas.setModel(modeloTabla);
        tblZonas.getSelectionModel().addListSelectionListener(
                evt -> cargarFilaSeleccionada());
        txtRecorrido.setEditable(false);
    }

    //Carga el árbol ABB desde el archivo XML
    private void cargarDatos() {
        Object cargado = XMLManager.cargar(ARCHIVO_XML);

        if (cargado instanceof ArbolABB) {
            arbol = (ArbolABB) cargado;
        } else {
            arbol = new ArbolABB();
        }
    }

    //Guarda el árbol ABB en el archivo XML
    public boolean guardarDatos() {
        return XMLManager.guardar(arbol, ARCHIVO_XML);
    }

    //Registra una nueva zona en el árbol ABB
    private void agregarZona() {
        try {
            int codigo = Integer.parseInt(txtCodigo.getText().trim());
            String nombre = txtNombre.getText().trim();
            String descripcion = txtDescripcion.getText().trim();

            if (codigo <= 0) {
                JOptionPane.showMessageDialog(this,
                        "El código debe ser mayor que cero.");
                return;
            }

            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Ingrese el nombre de la zona.");
                return;
            }

            boolean agregado = arbol.insertar(
                    new Zona(codigo, nombre, descripcion));

            if (!agregado) {
                JOptionPane.showMessageDialog(this,
                        "El código de zona ya existe.");
                return;
            }

            guardarDatos();
            llenarTabla();
            limpiarCampos();
            JOptionPane.showMessageDialog(this,
                    "Zona registrada correctamente.");
        } catch (NumberFormatException excepcion) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese un código numérico válido.");
        }
    }

    //Modifica los datos de una zona existente
    private void modificarZona() {
        try {
            int codigo = Integer.parseInt(txtCodigo.getText().trim());
            String nombre = txtNombre.getText().trim();
            String descripcion = txtDescripcion.getText().trim();

            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Ingrese el nombre de la zona.");
                return;
            }

            if (!arbol.actualizar(codigo, nombre, descripcion)) {
                JOptionPane.showMessageDialog(this,
                        "La zona no fue encontrada.");
                return;
            }

            guardarDatos();
            llenarTabla();
            limpiarCampos();
            JOptionPane.showMessageDialog(this,
                    "Zona modificada correctamente.");
        } catch (NumberFormatException excepcion) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese un código numérico válido.");
        }
    }

    //Elimina una zona del árbol ABB
    private void eliminarZona() {
        try {
            int codigo = Integer.parseInt(txtCodigo.getText().trim());
            Zona zona = arbol.buscar(codigo);

            if (zona == null) {
                JOptionPane.showMessageDialog(this,
                        "La zona no fue encontrada.");
                return;
            }

            int respuesta = JOptionPane.showConfirmDialog(this,
                    "¿Desea eliminar la zona " + zona.getNombre() + "?",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION);

            if (respuesta == JOptionPane.YES_OPTION) {
                arbol.eliminar(codigo);
                guardarDatos();
                llenarTabla();
                limpiarCampos();
                JOptionPane.showMessageDialog(this,
                        "Zona eliminada correctamente.");
            }
        } catch (NumberFormatException excepcion) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese un código numérico válido.");
        }
    }

    //Busca una zona mediante su código de ubicación
    private void buscarZona() {
        try {
            int codigo = Integer.parseInt(txtCodigo.getText().trim());
            Zona zona = arbol.buscar(codigo);

            if (zona == null) {
                JOptionPane.showMessageDialog(this,
                        "La zona no fue encontrada.");
                return;
            }

            txtNombre.setText(zona.getNombre());
            txtDescripcion.setText(zona.getDescripcion());
            seleccionarFila(codigo);
        } catch (NumberFormatException excepcion) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese un código numérico válido.");
        }
    }

    //Copia los datos de la fila seleccionada a los campos
    private void cargarFilaSeleccionada() {
        int fila = tblZonas.getSelectedRow();

        if (fila < 0 || modeloTabla == null) {
            return;
        }

        txtCodigo.setText(modeloTabla.getValueAt(fila, 0).toString());
        txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
        txtDescripcion.setText(modeloTabla.getValueAt(fila, 2).toString());
    }

    //Selecciona en la tabla la zona encontrada
    private void seleccionarFila(int codigo) {
        for (int fila = 0; fila < modeloTabla.getRowCount(); fila++) {
            int codigoFila = Integer.parseInt(
                    modeloTabla.getValueAt(fila, 0).toString());

            if (codigoFila == codigo) {
                tblZonas.setRowSelectionInterval(fila, fila);
                return;
            }
        }
    }

    //Limpia y vuelve a cargar la tabla mediante recorrido inorden
    private void llenarTabla() {
        if (modeloTabla == null || arbol == null) {
            return;
        }

        modeloTabla.setRowCount(0);
        llenarTablaRecursivo(arbol.getRaiz());
        txtRecorrido.setText("Recorrido inorden\n\n" + arbol.inOrden());
    }

    //Recorre el árbol de izquierda a derecha
    private void llenarTablaRecursivo(NodoABB nodo) {
        if (nodo != null) {
            llenarTablaRecursivo(nodo.getIzquierda());
            Zona zona = nodo.getValor();
            modeloTabla.addRow(new Object[]{
                zona.getCodigo(), zona.getNombre(), zona.getDescripcion()
            });
            llenarTablaRecursivo(nodo.getDerecha());
        }
    }

    //Limpia los campos del formulario
    private void limpiarCampos() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtDescripcion.setText("");
        tblZonas.clearSelection();
        txtCodigo.requestFocus();
    }

    //Muestra el resultado del guardado al usuario
    private void mostrarResultadoGuardado() {
        JOptionPane.showMessageDialog(this,
                guardarDatos()
                        ? "Las zonas fueron guardadas en XML."
                        : "No se pudieron guardar las zonas.");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        pnlDatos = new javax.swing.JPanel();
        lblCodigo = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblDescripcion = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        scrZonas = new javax.swing.JScrollPane();
        tblZonas = new javax.swing.JTable();
        scrRecorrido = new javax.swing.JScrollPane();
        txtRecorrido = new javax.swing.JTextArea();
        pnlBotones = new javax.swing.JPanel();
        btnAgregar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnInOrden = new javax.swing.JButton();
        btnPostOrden = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("UTP Park Manager - Infraestructura");

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("INFRAESTRUCTURA Y MAPA DEL PARQUE");

        pnlDatos.setBackground(new java.awt.Color(255, 255, 255));
        pnlDatos.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos de la zona"));

        lblCodigo.setText("Código de ubicación:");
        lblNombre.setText("Nombre:");
        lblDescripcion.setText("Descripción / tipo:");

        javax.swing.GroupLayout pnlDatosLayout = new javax.swing.GroupLayout(pnlDatos);
        pnlDatos.setLayout(pnlDatosLayout);
        pnlDatosLayout.setHorizontalGroup(
            pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDatosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblCodigo)
                    .addComponent(lblNombre)
                    .addComponent(lblDescripcion))
                .addGap(18, 18, 18)
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtCodigo)
                    .addComponent(txtNombre)
                    .addComponent(txtDescripcion))
                .addContainerGap())
        );
        pnlDatosLayout.setVerticalGroup(
            pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDatosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodigo)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombre)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDescripcion)
                    .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblZonas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {"Código", "Nombre", "Descripción"}
        ));
        scrZonas.setViewportView(tblZonas);

        txtRecorrido.setColumns(20);
        txtRecorrido.setRows(5);
        scrRecorrido.setBorder(javax.swing.BorderFactory.createTitledBorder("Recorrido del árbol"));
        scrRecorrido.setViewportView(txtRecorrido);

        pnlBotones.setBackground(new java.awt.Color(255, 255, 255));

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnInOrden.setText("Inorden");
        btnInOrden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInOrdenActionPerformed(evt);
            }
        });

        btnPostOrden.setText("Postorden");
        btnPostOrden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPostOrdenActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar XML");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlBotonesLayout = new javax.swing.GroupLayout(pnlBotones);
        pnlBotones.setLayout(pnlBotonesLayout);
        pnlBotonesLayout.setHorizontalGroup(
            pnlBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBotonesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnAgregar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnModificar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEliminar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBuscar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnInOrden)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPostOrden)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLimpiar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnGuardar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(btnCerrar)
                .addContainerGap())
        );
        pnlBotonesLayout.setVerticalGroup(
            pnlBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBotonesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar)
                    .addComponent(btnBuscar)
                    .addComponent(btnInOrden)
                    .addComponent(btnPostOrden)
                    .addComponent(btnLimpiar)
                    .addComponent(btnGuardar)
                    .addComponent(btnCerrar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDatos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(scrZonas)
                    .addComponent(scrRecorrido)
                    .addComponent(pnlBotones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlDatos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrZonas, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrRecorrido, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Eventos de los botones del formulario
    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        agregarZona();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        modificarZona();
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        eliminarZona();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        buscarZona();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnInOrdenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInOrdenActionPerformed
        txtRecorrido.setText("Recorrido inorden\n\n" + arbol.inOrden());
    }//GEN-LAST:event_btnInOrdenActionPerformed

    private void btnPostOrdenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPostOrdenActionPerformed
        txtRecorrido.setText("Recorrido postorden\n\n" + arbol.postOrden());
    }//GEN-LAST:event_btnPostOrdenActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        mostrarResultadoGuardado();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        guardarDatos();
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnInOrden;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnPostOrden;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel pnlBotones;
    private javax.swing.JPanel pnlDatos;
    private javax.swing.JScrollPane scrRecorrido;
    private javax.swing.JScrollPane scrZonas;
    private javax.swing.JTable tblZonas;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextArea txtRecorrido;
    // End of variables declaration//GEN-END:variables
}
