/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import conexionxml.XMLManager;
import estructura.ArbolAVLImpl;
import estructura.NodoPila;
import estructura.PilaTransacciones;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Transaccion;
import modelo.Visitante;

/**
 * Formulario del módulo financiero y reversiones.
 * Registra las operaciones en una pila y permite anular la última.
 *
 * @author Equipo UTP Park Manager
 */
public class FrmFinanciero extends javax.swing.JFrame {

    private static final String ARCHIVO_TRANSACCIONES = "transacciones.xml";
    private static final String ARCHIVO_VISITANTES = "visitantes.xml";

    private ArbolAVLImpl arbolVisitantes;
    private PilaTransacciones pila;
    private DefaultTableModel modeloTabla;

    //Constructor para abrir el formulario sin recibir estructuras
    public FrmFinanciero() {
        this(new ArbolAVLImpl());
    }

    //Constructor para recibir el árbol AVL del formulario principal
    public FrmFinanciero(ArbolAVLImpl arbolVisitantes) {
        initComponents();

        if (arbolVisitantes == null) {
            this.arbolVisitantes = new ArbolAVLImpl();
        } else {
            this.arbolVisitantes = arbolVisitantes;
        }

        cargarDatos();
        prepararTabla();
        llenarTabla();
        limpiarCampos();
        this.setLocationRelativeTo(null);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                guardarDatos();
            }
        });
    }

    //Prepara la tabla donde se muestran las transacciones
    private void prepararTabla() {
        modeloTabla = new DefaultTableModel(new String[]{
            "Transacción", "Brazalete", "Visitante", "Tipo",
            "Monto", "Fecha", "Descripción"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblTransacciones.setModel(modeloTabla);
    }

    //Carga la pila de transacciones desde el archivo XML
    private void cargarDatos() {
        Object cargado = XMLManager.cargar(ARCHIVO_TRANSACCIONES);

        if (cargado instanceof PilaTransacciones) {
            pila = (PilaTransacciones) cargado;
        } else {
            pila = new PilaTransacciones();
        }
    }

    //Guarda la pila y los saldos actualizados en XML
    public boolean guardarDatos() {
        boolean transaccionesGuardadas = XMLManager.guardar(
                pila, ARCHIVO_TRANSACCIONES);
        boolean visitantesGuardados = XMLManager.guardar(
                arbolVisitantes, ARCHIVO_VISITANTES);

        return transaccionesGuardadas && visitantesGuardados;
    }

    //Registra una compra o recarga y la apila mediante push
    private void registrarTransaccion() {
        try {
            int codigoTransaccion = Integer.parseInt(
                    txtCodigoTransaccion.getText().trim());
            int codigoBrazalete = Integer.parseInt(
                    txtCodigoBrazalete.getText().trim());
            double monto = Double.parseDouble(txtMonto.getText().trim());
            String tipo = cboTipo.getSelectedItem().toString();
            String fecha = txtFecha.getText().trim();
            String descripcion = txtDescripcion.getText().trim();

            if (codigoTransaccion <= 0 || codigoBrazalete <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Los códigos deben ser mayores que cero.");
                return;
            }

            if (monto <= 0) {
                JOptionPane.showMessageDialog(this,
                        "El monto debe ser mayor que cero.");
                return;
            }

            if (descripcion.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Ingrese una descripción de la operación.");
                return;
            }

            try {
                LocalDate.parse(fecha);
            } catch (Exception excepcion) {
                JOptionPane.showMessageDialog(this,
                        "La fecha debe tener el formato YYYY-MM-DD.");
                return;
            }

            if (existeCodigoTransaccion(codigoTransaccion)) {
                JOptionPane.showMessageDialog(this,
                        "El código de transacción ya existe.");
                return;
            }

            Visitante visitante = arbolVisitantes.buscar(codigoBrazalete);

            if (visitante == null) {
                JOptionPane.showMessageDialog(this,
                        "El brazalete no está registrado en Taquilla.");
                return;
            }

            if (tipo.equalsIgnoreCase("Compra")) {
                if (!visitante.descontarSaldo(monto)) {
                    JOptionPane.showMessageDialog(this,
                            "El visitante no tiene saldo suficiente.\nSaldo actual: S/ "
                            + String.format("%.2f", visitante.getSaldo()));
                    return;
                }
            } else {
                visitante.recargarSaldo(monto);
            }

            Transaccion transaccion = new Transaccion(
                    codigoTransaccion,
                    codigoBrazalete,
                    tipo,
                    monto,
                    fecha,
                    descripcion
            );

            pila.push(new NodoPila(transaccion));
            guardarDatos();
            llenarTabla();
            limpiarCampos();

            JOptionPane.showMessageDialog(this,
                    "Transacción registrada correctamente.\nNuevo saldo de "
                    + visitante.getNombre() + ": S/ "
                    + String.format("%.2f", visitante.getSaldo()));
        } catch (NumberFormatException excepcion) {
            JOptionPane.showMessageDialog(this,
                    "Los códigos y el monto deben ser numéricos.");
        }
    }

    //Revierte la última transacción mediante pop
    private void deshacerTransaccion() {
        Transaccion ultima = pila.peek();

        if (ultima == null) {
            JOptionPane.showMessageDialog(this,
                    "No existen transacciones para anular.");
            return;
        }

        Visitante visitante = arbolVisitantes.buscar(
                ultima.getCodigoBrazalete());

        if (visitante == null) {
            JOptionPane.showMessageDialog(this,
                    "No se puede anular porque el brazalete ya no existe.");
            return;
        }

        int respuesta = JOptionPane.showConfirmDialog(this,
                "¿Desea anular la última transacción?\n\n" + ultima,
                "Confirmar reversión LIFO",
                JOptionPane.YES_NO_OPTION);

        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }

        if (ultima.getTipo().equalsIgnoreCase("Compra")) {
            visitante.recargarSaldo(ultima.getMonto());
        } else {
            if (!visitante.descontarSaldo(ultima.getMonto())) {
                JOptionPane.showMessageDialog(this,
                        "No se puede revertir la recarga porque el saldo actual "
                        + "es menor que el monto recargado.");
                return;
            }
        }

        pila.pop();
        guardarDatos();
        llenarTabla();

        JOptionPane.showMessageDialog(this,
                "Transacción anulada correctamente.\nSaldo restaurado: S/ "
                + String.format("%.2f", visitante.getSaldo()));
    }

    //Busca al visitante en el árbol AVL y muestra su saldo
    private void validarBrazalete() {
        try {
            int codigo = Integer.parseInt(
                    txtCodigoBrazalete.getText().trim());
            Visitante visitante = arbolVisitantes.buscar(codigo);

            if (visitante == null) {
                JOptionPane.showMessageDialog(this,
                        "Brazalete no registrado.");
            } else {
                JOptionPane.showMessageDialog(this,
                        visitante.toString());
            }
        } catch (NumberFormatException excepcion) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese un código de brazalete numérico.");
        }
    }

    //Valida que el código de transacción no esté repetido
    private boolean existeCodigoTransaccion(int codigo) {
        NodoPila iterador = pila.getCabecera();

        while (iterador != null) {
            if (iterador.getElemento().getCodigo() == codigo) {
                return true;
            }
            iterador = iterador.getSiguiente();
        }

        return false;
    }

    //Recorre la pila desde el tope hasta el último nodo
    private void llenarTabla() {
        if (modeloTabla == null || pila == null) {
            return;
        }

        modeloTabla.setRowCount(0);
        double totalRecargas = 0.0;
        double totalCompras = 0.0;

        NodoPila iterador = pila.getCabecera();

        while (iterador != null) {
            Transaccion transaccion = iterador.getElemento();
            Visitante visitante = arbolVisitantes.buscar(
                    transaccion.getCodigoBrazalete());
            String nombre = visitante == null
                    ? "No registrado" : visitante.getNombre();

            modeloTabla.addRow(new Object[]{
                transaccion.getCodigo(),
                transaccion.getCodigoBrazalete(),
                nombre,
                transaccion.getTipo(),
                String.format("%.2f", transaccion.getMonto()),
                transaccion.getFecha(),
                transaccion.getDescripcion()
            });

            if (transaccion.getTipo().equalsIgnoreCase("Recarga")) {
                totalRecargas += transaccion.getMonto();
            } else {
                totalCompras += transaccion.getMonto();
            }

            iterador = iterador.getSiguiente();
        }

        lblTotalRecargas.setText("S/ " + String.format("%.2f", totalRecargas));
        lblTotalCompras.setText("S/ " + String.format("%.2f", totalCompras));
        lblMovimientoNeto.setText("S/ "
                + String.format("%.2f", totalRecargas - totalCompras));
    }

    //Limpia los campos de registro
    private void limpiarCampos() {
        txtCodigoTransaccion.setText("");
        txtCodigoBrazalete.setText("");
        txtMonto.setText("");
        txtFecha.setText(LocalDate.now().toString());
        txtDescripcion.setText("");
        cboTipo.setSelectedIndex(0);
        txtCodigoTransaccion.requestFocus();
    }

    //Muestra el resultado del guardado al usuario
    private void mostrarResultadoGuardado() {
        JOptionPane.showMessageDialog(this,
                guardarDatos()
                        ? "Las transacciones y saldos fueron guardados en XML."
                        : "No se pudieron guardar todos los datos.");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        pnlDatos = new javax.swing.JPanel();
        lblCodigoTransaccion = new javax.swing.JLabel();
        txtCodigoTransaccion = new javax.swing.JTextField();
        lblCodigoBrazalete = new javax.swing.JLabel();
        txtCodigoBrazalete = new javax.swing.JTextField();
        lblTipo = new javax.swing.JLabel();
        cboTipo = new javax.swing.JComboBox<>();
        lblMonto = new javax.swing.JLabel();
        txtMonto = new javax.swing.JTextField();
        lblFecha = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        lblDescripcion = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        pnlResumen = new javax.swing.JPanel();
        lblTextoRecargas = new javax.swing.JLabel();
        lblTotalRecargas = new javax.swing.JLabel();
        lblTextoCompras = new javax.swing.JLabel();
        lblTotalCompras = new javax.swing.JLabel();
        lblTextoNeto = new javax.swing.JLabel();
        lblMovimientoNeto = new javax.swing.JLabel();
        scrTransacciones = new javax.swing.JScrollPane();
        tblTransacciones = new javax.swing.JTable();
        pnlBotones = new javax.swing.JPanel();
        btnRegistrar = new javax.swing.JButton();
        btnDeshacer = new javax.swing.JButton();
        btnValidar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("UTP Park Manager - Financiero y Reversiones");

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("FINANCIERO Y REVERSIONES");

        pnlDatos.setBackground(new java.awt.Color(255, 255, 255));
        pnlDatos.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos de la transacción"));

        lblCodigoTransaccion.setText("Código de transacción:");
        lblCodigoBrazalete.setText("Código de brazalete:");
        lblTipo.setText("Tipo de operación:");
        cboTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Compra", "Recarga" }));
        lblMonto.setText("Monto (S/):");
        lblFecha.setText("Fecha (YYYY-MM-DD):");
        lblDescripcion.setText("Descripción:");

        javax.swing.GroupLayout pnlDatosLayout = new javax.swing.GroupLayout(pnlDatos);
        pnlDatos.setLayout(pnlDatosLayout);
        pnlDatosLayout.setHorizontalGroup(
            pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDatosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblCodigoTransaccion)
                    .addComponent(lblCodigoBrazalete)
                    .addComponent(lblTipo)
                    .addComponent(lblMonto)
                    .addComponent(lblFecha)
                    .addComponent(lblDescripcion))
                .addGap(18, 18, 18)
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtCodigoTransaccion)
                    .addComponent(txtCodigoBrazalete)
                    .addComponent(cboTipo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtMonto)
                    .addComponent(txtFecha)
                    .addComponent(txtDescripcion))
                .addContainerGap())
        );
        pnlDatosLayout.setVerticalGroup(
            pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDatosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodigoTransaccion)
                    .addComponent(txtCodigoTransaccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodigoBrazalete)
                    .addComponent(txtCodigoBrazalete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTipo)
                    .addComponent(cboTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMonto)
                    .addComponent(txtMonto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFecha)
                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDescripcion)
                    .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlResumen.setBackground(new java.awt.Color(255, 255, 255));
        pnlResumen.setBorder(javax.swing.BorderFactory.createTitledBorder("Resumen de la pila"));

        lblTextoRecargas.setText("Total recargas:");
        lblTotalRecargas.setText("S/ 0.00");
        lblTextoCompras.setText("Total compras:");
        lblTotalCompras.setText("S/ 0.00");
        lblTextoNeto.setText("Movimiento neto:");
        lblMovimientoNeto.setText("S/ 0.00");

        javax.swing.GroupLayout pnlResumenLayout = new javax.swing.GroupLayout(pnlResumen);
        pnlResumen.setLayout(pnlResumenLayout);
        pnlResumenLayout.setHorizontalGroup(
            pnlResumenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlResumenLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlResumenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTextoRecargas)
                    .addComponent(lblTextoCompras)
                    .addComponent(lblTextoNeto))
                .addGap(24, 24, 24)
                .addGroup(pnlResumenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTotalRecargas)
                    .addComponent(lblTotalCompras)
                    .addComponent(lblMovimientoNeto))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        pnlResumenLayout.setVerticalGroup(
            pnlResumenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlResumenLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(pnlResumenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTextoRecargas)
                    .addComponent(lblTotalRecargas))
                .addGap(28, 28, 28)
                .addGroup(pnlResumenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTextoCompras)
                    .addComponent(lblTotalCompras))
                .addGap(28, 28, 28)
                .addGroup(pnlResumenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTextoNeto)
                    .addComponent(lblMovimientoNeto))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblTransacciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {"Transacción", "Brazalete", "Visitante", "Tipo", "Monto", "Fecha", "Descripción"}
        ));
        scrTransacciones.setViewportView(tblTransacciones);

        pnlBotones.setBackground(new java.awt.Color(255, 255, 255));

        btnRegistrar.setText("Registrar (Push)");
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });

        btnDeshacer.setText("Anular última (Pop)");
        btnDeshacer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeshacerActionPerformed(evt);
            }
        });

        btnValidar.setText("Validar brazalete");
        btnValidar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnValidarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar XML");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlBotonesLayout = new javax.swing.GroupLayout(pnlBotones);
        pnlBotones.setLayout(pnlBotonesLayout);
        pnlBotonesLayout.setHorizontalGroup(
            pnlBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBotonesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnRegistrar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnDeshacer)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnValidar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnLimpiar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnGuardar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addComponent(btnCerrar)
                .addContainerGap())
        );
        pnlBotonesLayout.setVerticalGroup(
            pnlBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBotonesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRegistrar)
                    .addComponent(btnDeshacer)
                    .addComponent(btnValidar)
                    .addComponent(btnLimpiar)
                    .addComponent(btnGuardar)
                    .addComponent(btnCerrar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlDatos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pnlResumen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(scrTransacciones)
                    .addComponent(pnlBotones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnlDatos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlResumen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrTransacciones, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Eventos de los botones del formulario
    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        registrarTransaccion();
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void btnDeshacerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeshacerActionPerformed
        deshacerTransaccion();
    }//GEN-LAST:event_btnDeshacerActionPerformed

    private void btnValidarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnValidarActionPerformed
        validarBrazalete();
    }//GEN-LAST:event_btnValidarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        mostrarResultadoGuardado();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        guardarDatos();
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnDeshacer;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JButton btnValidar;
    private javax.swing.JComboBox<String> cboTipo;
    private javax.swing.JLabel lblCodigoBrazalete;
    private javax.swing.JLabel lblCodigoTransaccion;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblMonto;
    private javax.swing.JLabel lblMovimientoNeto;
    private javax.swing.JLabel lblTextoCompras;
    private javax.swing.JLabel lblTextoNeto;
    private javax.swing.JLabel lblTextoRecargas;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblTotalCompras;
    private javax.swing.JLabel lblTotalRecargas;
    private javax.swing.JPanel pnlBotones;
    private javax.swing.JPanel pnlDatos;
    private javax.swing.JPanel pnlResumen;
    private javax.swing.JScrollPane scrTransacciones;
    private javax.swing.JTable tblTransacciones;
    private javax.swing.JTextField txtCodigoBrazalete;
    private javax.swing.JTextField txtCodigoTransaccion;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtMonto;
    // End of variables declaration//GEN-END:variables
}
