/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import conexionxml.XMLManager;
import estructura.ArbolAVLImpl;
import estructura.ColaPrioridad;
import estructura.ListaCircular;
import estructura.ListaDoble;
import estructura.NodoCircular;
import estructura.NodoCola;
import estructura.NodoDoble;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import modelo.Atraccion;
import modelo.Visitante;

/**
 * Formulario del módulo de atracciones y operaciones.
 * Utiliza una lista doble, una cola de prioridad y una lista circular simple.
 *
 * @author Equipo UTP Park Manager
 */
public class FrmAtracciones extends javax.swing.JFrame {

    private static final String ARCHIVO_XML = "atracciones.xml";

    private ArbolAVLImpl arbolVisitantes;
    private Atraccion[] atracciones;

    //Constructor para abrir el formulario sin recibir estructuras
    public FrmAtracciones() {
        this(new ArbolAVLImpl());
    }

    //Constructor para recibir el árbol AVL del formulario principal
    public FrmAtracciones(ArbolAVLImpl arbolVisitantes) {
        initComponents();

        if (arbolVisitantes == null) {
            this.arbolVisitantes = new ArbolAVLImpl();
        } else {
            this.arbolVisitantes = arbolVisitantes;
        }

        cargarDatos();
        txtAreaVirtual.setEditable(false);
        txtAreaFisico.setEditable(false);
        txtAreaVagones.setEditable(false);
        actualizarVistas();
        this.setLocationRelativeTo(null);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                guardarDatos();
            }
        });
    }

    //Devuelve la atracción seleccionada en el ComboBox
    private Atraccion getAtraccionSeleccionada() {
        int posicion = cboAtracciones.getSelectedIndex();

        if (posicion < 0 || posicion >= atracciones.length) {
            posicion = 0;
        }

        return atracciones[posicion];
    }

    //Busca el brazalete en el árbol AVL creado en taquilla
    private Visitante obtenerVisitante(JTextField campoCodigo) {
        try {
            int codigo = Integer.parseInt(campoCodigo.getText().trim());
            Visitante visitante = arbolVisitantes.buscar(codigo);

            if (visitante == null) {
                JOptionPane.showMessageDialog(this,
                        "El brazalete no está registrado en Taquilla.",
                        "Visitante no encontrado",
                        JOptionPane.WARNING_MESSAGE);
            }

            return visitante;
        } catch (NumberFormatException excepcion) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese un código de brazalete numérico.",
                    "Dato incorrecto",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    //Inserta un brazalete al inicio, al final o en una posición de la lista doble
    private void insertarFilaVirtual(boolean alFinal, boolean porPosicion) {
        Visitante visitante = obtenerVisitante(txtVirtualCodigo);

        if (visitante == null) {
            return;
        }

        ListaDoble fila = getAtraccionSeleccionada().getFilaVirtual();
        NodoDoble nuevoNodo = new NodoDoble(visitante.getCodigoBrazalete());
        boolean agregado = true;

        if (porPosicion) {
            try {
                int posicion = Integer.parseInt(
                        txtVirtualPosicion.getText().trim());
                agregado = fila.insertarDentro(nuevoNodo, posicion);

                if (!agregado) {
                    JOptionPane.showMessageDialog(this,
                            "La posición debe estar entre 1 y "
                            + (fila.tamano() + 1) + ".");
                }
            } catch (NumberFormatException excepcion) {
                JOptionPane.showMessageDialog(this,
                        "Ingrese una posición numérica válida.");
                return;
            }
        } else if (alFinal) {
            fila.insertarFinal(nuevoNodo);
        } else {
            fila.insertarInicio(nuevoNodo);
        }

        if (agregado) {
            txtVirtualCodigo.setText("");
            txtVirtualPosicion.setText("");
            guardarDatos();
            actualizarVistas();
        }
    }

    //Retira un brazalete de una posición determinada
    private void retirarPosicionFilaVirtual() {
        try {
            int posicion = Integer.parseInt(
                    txtVirtualPosicion.getText().trim());
            Object eliminado = getAtraccionSeleccionada()
                    .getFilaVirtual().retirarDentro(posicion);

            if (eliminado == null) {
                JOptionPane.showMessageDialog(this,
                        "La posición indicada no existe.");
                return;
            }

            JOptionPane.showMessageDialog(this,
                    "Brazalete retirado de la fila: " + eliminado);
            txtVirtualPosicion.setText("");
            guardarDatos();
            actualizarVistas();
        } catch (NumberFormatException excepcion) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese una posición numérica válida.");
        }
    }

    //Retira el primer brazalete de la fila virtual
    private void retirarInicioFilaVirtual() {
        Object eliminado = getAtraccionSeleccionada()
                .getFilaVirtual().retirarInicio();

        if (eliminado == null) {
            JOptionPane.showMessageDialog(this,
                    "La fila virtual está vacía.");
            return;
        }

        JOptionPane.showMessageDialog(this,
                "Brazalete retirado del inicio: " + eliminado);
        guardarDatos();
        actualizarVistas();
    }

    //Encola al visitante según la prioridad de su tipo de pase
    private void encolarAccesoFisico() {
        Visitante visitante = obtenerVisitante(txtFisicoCodigo);

        if (visitante == null) {
            return;
        }

        getAtraccionSeleccionada().getColaAccesoFisico()
                .enqueue(new NodoCola(visitante));
        txtFisicoCodigo.setText("");
        guardarDatos();
        actualizarVistas();
    }

    //Desencola y atiende al visitante con mayor prioridad
    private void despacharAccesoFisico() {
        Visitante visitante = getAtraccionSeleccionada()
                .getColaAccesoFisico().dequeue();

        if (visitante == null) {
            JOptionPane.showMessageDialog(this,
                    "La cola de acceso está vacía.");
            return;
        }

        JOptionPane.showMessageDialog(this,
                "Acceso concedido a " + visitante.getNombre()
                + " (" + visitante.getTipoPase() + ").");
        guardarDatos();
        actualizarVistas();
    }

    //Agrega un vagón al final de la lista circular
    private void registrarVagon() {
        String identificador = txtVagonId.getText().trim();

        if (identificador.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese el número o ID del vagón.");
            return;
        }

        getAtraccionSeleccionada().getCicloVagones()
                .insertarFinal(new NodoCircular(identificador));
        txtVagonId.setText("");
        guardarDatos();
        actualizarVistas();
    }

    //Retira el vagón que se encuentra en la estación
    private void retirarVagon() {
        Object eliminado = getAtraccionSeleccionada()
                .getCicloVagones().retirarInicio();

        if (eliminado == null) {
            JOptionPane.showMessageDialog(this,
                    "No existen vagones registrados.");
            return;
        }

        JOptionPane.showMessageDialog(this,
                "Vagón retirado: " + eliminado);
        guardarDatos();
        actualizarVistas();
    }

    //Simula el recorrido retirando el primer vagón y colocándolo al final
    private void simularCiclo() {
        ListaCircular ciclo = getAtraccionSeleccionada().getCicloVagones();
        Object vagon = ciclo.retirarInicio();

        if (vagon == null) {
            JOptionPane.showMessageDialog(this,
                    "No existen vagones para simular el recorrido.");
            return;
        }

        ciclo.insertarFinal(new NodoCircular(vagon));
        JOptionPane.showMessageDialog(this,
                "El vagón " + vagon
                + " completó el recorrido y regresó al final del ciclo.");
        guardarDatos();
        actualizarVistas();
    }

    //Actualiza las áreas de texto con el estado de las estructuras
    private void actualizarVistas() {
        if (atracciones == null || atracciones.length == 0) {
            return;
        }

        Atraccion atraccion = getAtraccionSeleccionada();
        mostrarFilaVirtual(atraccion.getFilaVirtual());
        mostrarFilaFisica(atraccion.getColaAccesoFisico());
        mostrarVagones(atraccion.getCicloVagones());
    }

    //Recorre la lista doble y muestra los brazaletes reservados
    private void mostrarFilaVirtual(ListaDoble fila) {
        if (fila.estaVacia()) {
            txtAreaVirtual.setText("(Fila virtual vacía)");
            return;
        }

        StringBuilder cadena = new StringBuilder();
        NodoDoble iterador = fila.getInicio();
        int posicion = 1;

        while (iterador != null) {
            int codigo = Integer.parseInt(iterador.getElemento().toString());
            Visitante visitante = arbolVisitantes.buscar(codigo);
            cadena.append(posicion).append(". Brazalete ").append(codigo);

            if (visitante != null) {
                cadena.append(" - ").append(visitante.getNombre());
            } else {
                cadena.append(" - visitante no registrado");
            }

            cadena.append("\n");
            iterador = iterador.getSiguiente();
            posicion++;
        }

        txtAreaVirtual.setText(cadena.toString());
    }

    //Recorre la cola de prioridad sin modificar su orden
    private void mostrarFilaFisica(ColaPrioridad cola) {
        if (cola.estaVacia()) {
            txtAreaFisico.setText("(Cola de acceso vacía)");
            return;
        }

        StringBuilder cadena = new StringBuilder();
        NodoCola iterador = cola.getCabecera();
        int posicion = 1;

        while (iterador != null) {
            Visitante visitante = iterador.getElemento();
            cadena.append(posicion)
                    .append(". ")
                    .append(visitante.getCodigoBrazalete())
                    .append(" - ")
                    .append(visitante.getNombre())
                    .append(" [")
                    .append(visitante.getTipoPase())
                    .append("]\n");
            iterador = iterador.getSiguiente();
            posicion++;
        }

        txtAreaFisico.setText(cadena.toString());
    }

    //Recorre una vuelta completa de la lista circular
    private void mostrarVagones(ListaCircular ciclo) {
        if (ciclo.estaVacia()) {
            txtAreaVagones.setText("(Sin vagones en servicio)");
            return;
        }

        StringBuilder cadena = new StringBuilder();
        NodoCircular iterador = ciclo.getCabecera();
        int posicion = 1;

        do {
            cadena.append(posicion)
                    .append(". Estación -> Vagón ")
                    .append(iterador.getElemento())
                    .append("\n");
            iterador = iterador.getSiguiente();
            posicion++;
        } while (iterador != ciclo.getCabecera());

        txtAreaVagones.setText(cadena.toString());
    }

    //Carga el arreglo de atracciones desde el archivo XML
    private void cargarDatos() {
        Object cargado = XMLManager.cargar(ARCHIVO_XML);

        if (cargado instanceof Atraccion[]) {
            atracciones = (Atraccion[]) cargado;
        } else {
            atracciones = crearAtraccionesIniciales();
        }

        if (atracciones.length != 3) {
            atracciones = crearAtraccionesIniciales();
        }

        Atraccion[] iniciales = crearAtraccionesIniciales();

        for (int i = 0; i < atracciones.length; i++) {
            if (atracciones[i] == null) {
                atracciones[i] = iniciales[i];
            }
            if (atracciones[i].getFilaVirtual() == null) {
                atracciones[i].setFilaVirtual(new ListaDoble());
            }
            if (atracciones[i].getCicloVagones() == null) {
                atracciones[i].setCicloVagones(new ListaCircular());
            }
            if (atracciones[i].getColaAccesoFisico() == null) {
                atracciones[i].setColaAccesoFisico(new ColaPrioridad());
            }
        }
    }

    //Crea los datos iniciales cuando el archivo XML todavía no existe
    private Atraccion[] crearAtraccionesIniciales() {
        return new Atraccion[]{
            new Atraccion("Montaña Rusa", 5),
            new Atraccion("Carrusel", 10),
            new Atraccion("Rueda de la Fortuna", 8)
        };
    }

    //Guarda todo el estado del módulo en el archivo XML
    public boolean guardarDatos() {
        return XMLManager.guardar(atracciones, ARCHIVO_XML);
    }

    //Muestra el resultado del guardado al usuario
    private void mostrarResultadoGuardado() {
        JOptionPane.showMessageDialog(this,
                guardarDatos()
                        ? "Los datos de atracciones fueron guardados en XML."
                        : "No se pudieron guardar los datos de atracciones.");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        pnlSelector = new javax.swing.JPanel();
        lblAtraccion = new javax.swing.JLabel();
        cboAtracciones = new javax.swing.JComboBox<>();
        pnlFilaVirtual = new javax.swing.JPanel();
        lblVirtualCodigo = new javax.swing.JLabel();
        txtVirtualCodigo = new javax.swing.JTextField();
        btnInsertarInicio = new javax.swing.JButton();
        btnInsertarFinal = new javax.swing.JButton();
        lblVirtualPosicion = new javax.swing.JLabel();
        txtVirtualPosicion = new javax.swing.JTextField();
        btnInsertarPosicion = new javax.swing.JButton();
        btnRetirarPosicion = new javax.swing.JButton();
        btnRetirarInicio = new javax.swing.JButton();
        scrVirtual = new javax.swing.JScrollPane();
        txtAreaVirtual = new javax.swing.JTextArea();
        pnlFilaFisica = new javax.swing.JPanel();
        lblFisicoCodigo = new javax.swing.JLabel();
        txtFisicoCodigo = new javax.swing.JTextField();
        lblPrioridad = new javax.swing.JLabel();
        btnEncolar = new javax.swing.JButton();
        btnDespachar = new javax.swing.JButton();
        scrFisico = new javax.swing.JScrollPane();
        txtAreaFisico = new javax.swing.JTextArea();
        pnlVagones = new javax.swing.JPanel();
        lblVagon = new javax.swing.JLabel();
        txtVagonId = new javax.swing.JTextField();
        btnRegistrarVagon = new javax.swing.JButton();
        btnRetirarVagon = new javax.swing.JButton();
        btnSimular = new javax.swing.JButton();
        scrVagones = new javax.swing.JScrollPane();
        txtAreaVagones = new javax.swing.JTextArea();
        btnGuardar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("UTP Park Manager - Atracciones y Operaciones");

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("ATRACCIONES Y OPERACIONES");

        pnlSelector.setBackground(new java.awt.Color(255, 255, 255));
        lblAtraccion.setText("Atracción:");
        cboAtracciones.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Montaña Rusa", "Carrusel", "Rueda de la Fortuna" }));
        cboAtracciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboAtraccionesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlSelectorLayout = new javax.swing.GroupLayout(pnlSelector);
        pnlSelector.setLayout(pnlSelectorLayout);
        pnlSelectorLayout.setHorizontalGroup(
            pnlSelectorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSelectorLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblAtraccion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cboAtracciones, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlSelectorLayout.setVerticalGroup(
            pnlSelectorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSelectorLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlSelectorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAtraccion)
                    .addComponent(cboAtracciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlFilaVirtual.setBackground(new java.awt.Color(255, 255, 255));
        pnlFilaVirtual.setBorder(javax.swing.BorderFactory.createTitledBorder("Fila virtual - Lista enlazada doble"));
        lblVirtualCodigo.setText("Código de brazalete:");
        btnInsertarInicio.setText("Insertar inicio");
        btnInsertarInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarInicioActionPerformed(evt);
            }
        });
        btnInsertarFinal.setText("Insertar final");
        btnInsertarFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarFinalActionPerformed(evt);
            }
        });
        lblVirtualPosicion.setText("Posición (empieza en 1):");
        btnInsertarPosicion.setText("Insertar posición");
        btnInsertarPosicion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarPosicionActionPerformed(evt);
            }
        });
        btnRetirarPosicion.setText("Retirar posición");
        btnRetirarPosicion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetirarPosicionActionPerformed(evt);
            }
        });
        btnRetirarInicio.setText("Retirar del inicio");
        btnRetirarInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetirarInicioActionPerformed(evt);
            }
        });
        txtAreaVirtual.setColumns(20);
        txtAreaVirtual.setRows(5);
        scrVirtual.setViewportView(txtAreaVirtual);

        javax.swing.GroupLayout pnlFilaVirtualLayout = new javax.swing.GroupLayout(pnlFilaVirtual);
        pnlFilaVirtual.setLayout(pnlFilaVirtualLayout);
        pnlFilaVirtualLayout.setHorizontalGroup(
            pnlFilaVirtualLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFilaVirtualLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlFilaVirtualLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblVirtualCodigo)
                    .addComponent(txtVirtualCodigo)
                    .addGroup(pnlFilaVirtualLayout.createSequentialGroup()
                        .addComponent(btnInsertarInicio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnInsertarFinal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lblVirtualPosicion)
                    .addComponent(txtVirtualPosicion)
                    .addGroup(pnlFilaVirtualLayout.createSequentialGroup()
                        .addComponent(btnInsertarPosicion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRetirarPosicion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(btnRetirarInicio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(scrVirtual, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlFilaVirtualLayout.setVerticalGroup(
            pnlFilaVirtualLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFilaVirtualLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblVirtualCodigo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtVirtualCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlFilaVirtualLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertarInicio)
                    .addComponent(btnInsertarFinal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblVirtualPosicion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtVirtualPosicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlFilaVirtualLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertarPosicion)
                    .addComponent(btnRetirarPosicion))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRetirarInicio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrVirtual, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlFilaFisica.setBackground(new java.awt.Color(255, 255, 255));
        pnlFilaFisica.setBorder(javax.swing.BorderFactory.createTitledBorder("Acceso físico - Cola de prioridad"));
        lblFisicoCodigo.setText("Código de brazalete:");
        lblPrioridad.setText("VIP 3 - FastPass 2 - Regular 1");
        btnEncolar.setText("Ingresar a la cola");
        btnEncolar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEncolarActionPerformed(evt);
            }
        });
        btnDespachar.setText("Despachar siguiente");
        btnDespachar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDespacharActionPerformed(evt);
            }
        });
        txtAreaFisico.setColumns(20);
        txtAreaFisico.setRows(5);
        scrFisico.setViewportView(txtAreaFisico);

        javax.swing.GroupLayout pnlFilaFisicaLayout = new javax.swing.GroupLayout(pnlFilaFisica);
        pnlFilaFisica.setLayout(pnlFilaFisicaLayout);
        pnlFilaFisicaLayout.setHorizontalGroup(
            pnlFilaFisicaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFilaFisicaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlFilaFisicaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFisicoCodigo)
                    .addComponent(txtFisicoCodigo)
                    .addComponent(lblPrioridad)
                    .addComponent(btnEncolar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDespachar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(scrFisico, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlFilaFisicaLayout.setVerticalGroup(
            pnlFilaFisicaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFilaFisicaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblFisicoCodigo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFisicoCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblPrioridad)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEncolar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDespachar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrFisico)
                .addContainerGap())
        );

        pnlVagones.setBackground(new java.awt.Color(255, 255, 255));
        pnlVagones.setBorder(javax.swing.BorderFactory.createTitledBorder("Ciclo de vagones - Lista circular simple"));
        lblVagon.setText("Número o ID del vagón:");
        btnRegistrarVagon.setText("Registrar vagón");
        btnRegistrarVagon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarVagonActionPerformed(evt);
            }
        });
        btnRetirarVagon.setText("Retirar vagón");
        btnRetirarVagon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetirarVagonActionPerformed(evt);
            }
        });
        btnSimular.setText("Simular recorrido");
        btnSimular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimularActionPerformed(evt);
            }
        });
        txtAreaVagones.setColumns(20);
        txtAreaVagones.setRows(5);
        scrVagones.setViewportView(txtAreaVagones);

        javax.swing.GroupLayout pnlVagonesLayout = new javax.swing.GroupLayout(pnlVagones);
        pnlVagones.setLayout(pnlVagonesLayout);
        pnlVagonesLayout.setHorizontalGroup(
            pnlVagonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVagonesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlVagonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblVagon)
                    .addComponent(txtVagonId)
                    .addComponent(btnRegistrarVagon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRetirarVagon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSimular, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(scrVagones, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlVagonesLayout.setVerticalGroup(
            pnlVagonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVagonesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblVagon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtVagonId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnRegistrarVagon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRetirarVagon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSimular)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrVagones)
                .addContainerGap())
        );

        btnGuardar.setText("Guardar XML");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlSelector, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlFilaVirtual, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlFilaFisica, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlVagones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnGuardar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnCerrar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlSelector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlFilaVirtual, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlFilaFisica, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlVagones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnCerrar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Eventos del formulario
    private void cboAtraccionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboAtraccionesActionPerformed
        actualizarVistas();
    }//GEN-LAST:event_cboAtraccionesActionPerformed

    private void btnInsertarInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarInicioActionPerformed
        insertarFilaVirtual(false, false);
    }//GEN-LAST:event_btnInsertarInicioActionPerformed

    private void btnInsertarFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarFinalActionPerformed
        insertarFilaVirtual(true, false);
    }//GEN-LAST:event_btnInsertarFinalActionPerformed

    private void btnInsertarPosicionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarPosicionActionPerformed
        insertarFilaVirtual(false, true);
    }//GEN-LAST:event_btnInsertarPosicionActionPerformed

    private void btnRetirarPosicionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetirarPosicionActionPerformed
        retirarPosicionFilaVirtual();
    }//GEN-LAST:event_btnRetirarPosicionActionPerformed

    private void btnRetirarInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetirarInicioActionPerformed
        retirarInicioFilaVirtual();
    }//GEN-LAST:event_btnRetirarInicioActionPerformed

    private void btnEncolarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEncolarActionPerformed
        encolarAccesoFisico();
    }//GEN-LAST:event_btnEncolarActionPerformed

    private void btnDespacharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDespacharActionPerformed
        despacharAccesoFisico();
    }//GEN-LAST:event_btnDespacharActionPerformed

    private void btnRegistrarVagonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarVagonActionPerformed
        registrarVagon();
    }//GEN-LAST:event_btnRegistrarVagonActionPerformed

    private void btnRetirarVagonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetirarVagonActionPerformed
        retirarVagon();
    }//GEN-LAST:event_btnRetirarVagonActionPerformed

    private void btnSimularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimularActionPerformed
        simularCiclo();
    }//GEN-LAST:event_btnSimularActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        mostrarResultadoGuardado();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        guardarDatos();
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnDespachar;
    private javax.swing.JButton btnEncolar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnInsertarFinal;
    private javax.swing.JButton btnInsertarInicio;
    private javax.swing.JButton btnInsertarPosicion;
    private javax.swing.JButton btnRegistrarVagon;
    private javax.swing.JButton btnRetirarInicio;
    private javax.swing.JButton btnRetirarPosicion;
    private javax.swing.JButton btnRetirarVagon;
    private javax.swing.JButton btnSimular;
    private javax.swing.JComboBox<String> cboAtracciones;
    private javax.swing.JLabel lblAtraccion;
    private javax.swing.JLabel lblFisicoCodigo;
    private javax.swing.JLabel lblPrioridad;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblVagon;
    private javax.swing.JLabel lblVirtualCodigo;
    private javax.swing.JLabel lblVirtualPosicion;
    private javax.swing.JPanel pnlFilaFisica;
    private javax.swing.JPanel pnlFilaVirtual;
    private javax.swing.JPanel pnlSelector;
    private javax.swing.JPanel pnlVagones;
    private javax.swing.JScrollPane scrFisico;
    private javax.swing.JScrollPane scrVagones;
    private javax.swing.JScrollPane scrVirtual;
    private javax.swing.JTextArea txtAreaFisico;
    private javax.swing.JTextArea txtAreaVagones;
    private javax.swing.JTextArea txtAreaVirtual;
    private javax.swing.JTextField txtFisicoCodigo;
    private javax.swing.JTextField txtVagonId;
    private javax.swing.JTextField txtVirtualCodigo;
    private javax.swing.JTextField txtVirtualPosicion;
    // End of variables declaration//GEN-END:variables
}
