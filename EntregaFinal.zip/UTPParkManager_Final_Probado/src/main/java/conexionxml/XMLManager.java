package conexionxml;

import java.beans.ExceptionListener;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * Operaciones básicas de persistencia mediante XMLDecoder y XMLEncoder.
 *
 * @author Equipo UTP Park Manager
 */
public final class XMLManager {

    private XMLManager() {
    }

    //Guarda un objeto o una estructura mediante XMLEncoder
    public static boolean guardar(Object objeto, String nombreArchivo) {
        final boolean[] ocurrioError = {false};
        String ruta = ConexionXML.getRuta(nombreArchivo);

        try (XMLEncoder encoder = new XMLEncoder(
                new BufferedOutputStream(new FileOutputStream(ruta)))) {

            encoder.setExceptionListener(new ExceptionListener() {
                @Override
                public void exceptionThrown(Exception excepcion) {
                    ocurrioError[0] = true;
                    excepcion.printStackTrace();
                }
            });

            encoder.writeObject(objeto);
            encoder.flush();
            return !ocurrioError[0];
        } catch (Exception excepcion) {
            excepcion.printStackTrace();
            return false;
        }
    }

    //Recupera un objeto del archivo XML mediante XMLDecoder
    public static Object cargar(String nombreArchivo) {
        String ruta = ConexionXML.getRuta(nombreArchivo);
        File archivo = new File(ruta);

        if (!archivo.exists() || archivo.length() == 0) {
            return null;
        }

        try (XMLDecoder decoder = new XMLDecoder(
                new BufferedInputStream(new FileInputStream(archivo)))) {
            return decoder.readObject();
        } catch (Exception excepcion) {
            System.err.println("No se pudo cargar " + nombreArchivo
                    + ": " + excepcion.getMessage());
            return null;
        }
    }
}
