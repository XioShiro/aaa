package conexionxml;

import java.io.File;

/**
 * Administra la carpeta donde se guardan los archivos XML del sistema.
 *
 * @author Equipo UTP Park Manager
 */
public final class ConexionXML {

    private static final String CARPETA = System.getProperty("user.dir")
            + File.separator + "datos";

    private ConexionXML() {
    }

    //Crea la carpeta de datos y devuelve la ruta del archivo XML
    public static String getRuta(String nombreArchivo) {
        File carpeta = new File(CARPETA);
        if (!carpeta.exists()) {
            carpeta.mkdirs();
        }
        return CARPETA + File.separator + nombreArchivo;
    }
}
