package estructura;

/**
 * Nodo de la Lista Enlazada Circular Simple.
 *
 * @author Equipo UTP Park Manager
 */
public class NodoCircular {

    private Object elemento;
    private NodoCircular siguiente;

    public NodoCircular() {
        this.elemento = null;
        this.siguiente = null;
    }

    public NodoCircular(Object elemento) {
        this();
        this.elemento = elemento;
    }

    public Object getElemento() {
        return elemento;
    }

    public void setElemento(Object elemento) {
        this.elemento = elemento;
    }

    public NodoCircular getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCircular siguiente) {
        this.siguiente = siguiente;
    }
}
