package estructura;

import modelo.Visitante;

/**
 * Nodo de la Cola de Prioridad.
 *
 * @author Equipo UTP Park Manager
 */
public class NodoCola {

    private Visitante elemento;
    private NodoCola siguiente;

    public NodoCola() {
        this.elemento = null;
        this.siguiente = null;
    }

    public NodoCola(Visitante elemento) {
        this();
        this.elemento = elemento;
    }

    public NodoCola(Visitante elemento, NodoCola siguiente) {
        this.elemento = elemento;
        this.siguiente = siguiente;
    }

    public Visitante getElemento() {
        return elemento;
    }

    public void setElemento(Visitante elemento) {
        this.elemento = elemento;
    }

    public NodoCola getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCola siguiente) {
        this.siguiente = siguiente;
    }
}
