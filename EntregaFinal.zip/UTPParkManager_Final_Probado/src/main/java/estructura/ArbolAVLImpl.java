package estructura;

import interfaces.InterfaceArbolAvl;
import modelo.Visitante;

/**
 * Implementación del TAD Árbol AVL.
 * La clave de ordenamiento es el código único del brazalete.
 *
 * @author Equipo UTP Park Manager
 */
public class ArbolAVLImpl implements InterfaceArbolAvl {

    private NodoAVL raiz;
    private int nNodos;

    //Constructor del arbol AVL
    public ArbolAVLImpl() {
        this.raiz = null;
        this.nNodos = 0;
    }

    public NodoAVL getRaiz() {
        return raiz;
    }

    public void setRaiz(NodoAVL raiz) {
        this.raiz = raiz;
    }

    public int getNNodos() {
        return nNodos;
    }

    public void setNNodos(int nNodos) {
        this.nNodos = nNodos;
    }

    @Override
    //Verifica si el arbol AVL no tiene visitantes
    public boolean estaVacio() {
        return raiz == null;
    }

    @Override
    //Elimina todos los nodos del arbol
    public void vaciar() {
        raiz = null;
        nNodos = 0;
    }

    @Override
    //Devuelve la cantidad de visitantes registrados
    public int tamano() {
        return nNodos;
    }

    @Override
    //Agrega un visitante y conserva el balance del arbol
    public boolean agregar(Visitante visitante) {
        if (visitante == null || contiene(visitante.getCodigoBrazalete())) {
            return false;
        }

        raiz = insertarRecursivo(raiz, visitante);
        nNodos++;
        return true;
    }

    //Inserta recursivamente el visitante segun su codigo de brazalete
    private NodoAVL insertarRecursivo(NodoAVL nodo, Visitante visitante) {
        if (nodo == null) {
            return new NodoAVL(visitante);
        }

        int codigo = visitante.getCodigoBrazalete();
        int codigoNodo = nodo.getValor().getCodigoBrazalete();

        if (codigo < codigoNodo) {
            nodo.setIzquierda(insertarRecursivo(nodo.getIzquierda(), visitante));
        } else {
            nodo.setDerecha(insertarRecursivo(nodo.getDerecha(), visitante));
        }

        actualizarAltura(nodo);
        return balancear(nodo);
    }

    @Override
    //Busca un visitante mediante el codigo de su brazalete
    public Visitante buscar(int codigoBrazalete) {
        NodoAVL encontrado = buscarNodo(codigoBrazalete, raiz);
        return encontrado == null ? null : encontrado.getValor();
    }

    @Override
    //Valida si un codigo de brazalete ya existe
    public boolean contiene(int codigoBrazalete) {
        return buscarNodo(codigoBrazalete, raiz) != null;
    }

    //Recorre el arbol hasta encontrar el nodo solicitado
    private NodoAVL buscarNodo(int codigoBrazalete, NodoAVL nodo) {
        NodoAVL iterador = nodo;

        while (iterador != null) {
            int codigoActual = iterador.getValor().getCodigoBrazalete();

            if (codigoBrazalete < codigoActual) {
                iterador = iterador.getIzquierda();
            } else if (codigoBrazalete > codigoActual) {
                iterador = iterador.getDerecha();
            } else {
                return iterador;
            }
        }

        return null;
    }

    @Override
    //Elimina un visitante y vuelve a balancear el arbol
    public boolean eliminar(int codigoBrazalete) {
        if (!contiene(codigoBrazalete)) {
            return false;
        }

        raiz = eliminarRecursivo(raiz, codigoBrazalete);
        nNodos--;
        return true;
    }

    //Elimina recursivamente considerando los tres casos del arbol
    private NodoAVL eliminarRecursivo(NodoAVL nodo, int codigoBrazalete) {
        if (nodo == null) {
            return null;
        }

        int codigoNodo = nodo.getValor().getCodigoBrazalete();

        if (codigoBrazalete < codigoNodo) {
            nodo.setIzquierda(eliminarRecursivo(nodo.getIzquierda(), codigoBrazalete));
        } else if (codigoBrazalete > codigoNodo) {
            nodo.setDerecha(eliminarRecursivo(nodo.getDerecha(), codigoBrazalete));
        } else {
            if (nodo.getIzquierda() == null) {
                return nodo.getDerecha();
            }

            if (nodo.getDerecha() == null) {
                return nodo.getIzquierda();
            }

            NodoAVL sucesor = encontrarMinimo(nodo.getDerecha());
            nodo.setValor(sucesor.getValor());
            nodo.setDerecha(eliminarRecursivo(
                    nodo.getDerecha(),
                    sucesor.getValor().getCodigoBrazalete()
            ));
        }

        actualizarAltura(nodo);
        return balancear(nodo);
    }

    //Busca el nodo menor del subarbol derecho
    public NodoAVL encontrarMinimo(NodoAVL nodo) {
        NodoAVL iterador = nodo;
        while (iterador != null && iterador.getIzquierda() != null) {
            iterador = iterador.getIzquierda();
        }
        return iterador;
    }

    //Calcula el factor de balance y aplica las rotaciones necesarias
    private NodoAVL balancear(NodoAVL nodo) {
        int factor = factorBalance(nodo);

        if (factor > 1) {
            if (factorBalance(nodo.getIzquierda()) < 0) {
                nodo.setIzquierda(rotacionIzquierda(nodo.getIzquierda()));
            }
            return rotacionDerecha(nodo);
        }

        if (factor < -1) {
            if (factorBalance(nodo.getDerecha()) > 0) {
                nodo.setDerecha(rotacionDerecha(nodo.getDerecha()));
            }
            return rotacionIzquierda(nodo);
        }

        return nodo;
    }

    //Realiza una rotacion simple hacia la derecha
    private NodoAVL rotacionDerecha(NodoAVL nodo) {
        NodoAVL nuevaRaiz = nodo.getIzquierda();
        NodoAVL temporal = nuevaRaiz.getDerecha();

        nuevaRaiz.setDerecha(nodo);
        nodo.setIzquierda(temporal);

        actualizarAltura(nodo);
        actualizarAltura(nuevaRaiz);
        return nuevaRaiz;
    }

    //Realiza una rotacion simple hacia la izquierda
    private NodoAVL rotacionIzquierda(NodoAVL nodo) {
        NodoAVL nuevaRaiz = nodo.getDerecha();
        NodoAVL temporal = nuevaRaiz.getIzquierda();

        nuevaRaiz.setIzquierda(nodo);
        nodo.setDerecha(temporal);

        actualizarAltura(nodo);
        actualizarAltura(nuevaRaiz);
        return nuevaRaiz;
    }

    //Devuelve la altura de un nodo
    private int altura(NodoAVL nodo) {
        return nodo == null ? -1 : nodo.getAltura();
    }

    //Calcula la diferencia entre la altura izquierda y derecha
    private int factorBalance(NodoAVL nodo) {
        return nodo == null ? 0 : altura(nodo.getIzquierda()) - altura(nodo.getDerecha());
    }

    //Actualiza la altura despues de insertar, eliminar o rotar
    private void actualizarAltura(NodoAVL nodo) {
        if (nodo != null) {
            nodo.setAltura(Math.max(
                    altura(nodo.getIzquierda()),
                    altura(nodo.getDerecha())
            ) + 1);
        }
    }

    @Override
    //Imprime los visitantes mediante recorrido inorden
    public void imprimir() {
        System.out.println(mostrarVisitantes());
    }

    @Override
    //Devuelve los visitantes ordenados por codigo
    public String mostrarVisitantes() {
        if (estaVacio()) {
            return "ÁRBOL VACÍO";
        }

        StringBuilder cadena = new StringBuilder();
        mostrarInOrden(raiz, cadena);
        return cadena.toString();
    }

    //Recorre el subarbol izquierdo, la raiz y el subarbol derecho
    private void mostrarInOrden(NodoAVL nodo, StringBuilder cadena) {
        if (nodo != null) {
            mostrarInOrden(nodo.getIzquierda(), cadena);
            cadena.append(nodo.getValor().toString()).append("\n\n");
            mostrarInOrden(nodo.getDerecha(), cadena);
        }
    }
}
