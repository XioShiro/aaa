package estructura;

import modelo.Transaccion;

/**
 * Nodo de la Pila de Transacciones.
 *
 * @author Equipo UTP Park Manager
 */
public class NodoPila {

    private Transaccion elemento;
    private NodoPila siguiente;

    public NodoPila() {
        this.elemento = null;
        this.siguiente = null;
    }

    public NodoPila(Transaccion elemento) {
        this();
        this.elemento = elemento;
    }

    public Transaccion getElemento() {
        return elemento;
    }

    public void setElemento(Transaccion elemento) {
        this.elemento = elemento;
    }

    public NodoPila getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoPila siguiente) {
        this.siguiente = siguiente;
    }
}
