package estructura;

/**
 * Nodo de la Lista Enlazada Doble.
 *
 * @author Equipo UTP Park Manager
 */
public class NodoDoble {

    private Object elemento;
    private NodoDoble siguiente;
    private NodoDoble anterior;

    public NodoDoble() {
        this.elemento = null;
        this.siguiente = null;
        this.anterior = null;
    }

    public NodoDoble(Object elemento) {
        this();
        this.elemento = elemento;
    }

    public Object getElemento() {
        return elemento;
    }

    public void setElemento(Object elemento) {
        this.elemento = elemento;
    }

    public NodoDoble getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoDoble siguiente) {
        this.siguiente = siguiente;
    }

    public NodoDoble getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoDoble anterior) {
        this.anterior = anterior;
    }
}
