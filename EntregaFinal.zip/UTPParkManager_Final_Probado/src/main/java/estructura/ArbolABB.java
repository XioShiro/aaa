package estructura;

import interfaces.InterfaceArbolAbb;
import modelo.Zona;

/**
 * Implementación del TAD Árbol Binario de Búsqueda estándar.
 * No realiza balanceo para permitir comparar su comportamiento con el AVL.
 *
 * @author Equipo UTP Park Manager
 */
public class ArbolABB implements InterfaceArbolAbb {

    private NodoABB raiz;
    private int nNodos;

    //Constructor del arbol binario de busqueda
    public ArbolABB() {
        this.raiz = null;
        this.nNodos = 0;
    }

    @Override
    public NodoABB getRaiz() {
        return raiz;
    }

    public void setRaiz(NodoABB raiz) {
        this.raiz = raiz;
    }

    public int getNNodos() {
        return nNodos;
    }

    public void setNNodos(int nNodos) {
        this.nNodos = nNodos;
    }

    @Override
    //Verifica si el arbol no contiene zonas
    public boolean estaVacio() {
        return raiz == null;
    }

    @Override
    //Elimina todas las zonas del arbol
    public void vaciar() {
        raiz = null;
        nNodos = 0;
    }

    @Override
    //Devuelve la cantidad de zonas registradas
    public int tamano() {
        return nNodos;
    }

    @Override
    //Inserta una zona segun su codigo de ubicacion
    public boolean insertar(Zona zona) {
        if (zona == null || buscar(zona.getCodigo()) != null) {
            return false;
        }

        NodoABB nuevoNodo = new NodoABB(zona);

        if (estaVacio()) {
            raiz = nuevoNodo;
            nNodos++;
            return true;
        }

        NodoABB padre = null;
        NodoABB iterador = raiz;

        while (iterador != null) {
            padre = iterador;
            if (zona.getCodigo() < iterador.getValor().getCodigo()) {
                iterador = iterador.getIzquierda();
            } else {
                iterador = iterador.getDerecha();
            }
        }

        if (zona.getCodigo() < padre.getValor().getCodigo()) {
            padre.setIzquierda(nuevoNodo);
        } else {
            padre.setDerecha(nuevoNodo);
        }

        nNodos++;
        return true;
    }

    @Override
    //Busca una zona mediante su codigo
    public Zona buscar(int codigo) {
        NodoABB iterador = raiz;

        while (iterador != null) {
            int codigoActual = iterador.getValor().getCodigo();
            if (codigo < codigoActual) {
                iterador = iterador.getIzquierda();
            } else if (codigo > codigoActual) {
                iterador = iterador.getDerecha();
            } else {
                return iterador.getValor();
            }
        }

        return null;
    }

    @Override
    //Modifica los datos de una zona existente
    public boolean actualizar(int codigo, String nombre, String descripcion) {
        Zona zona = buscar(codigo);
        if (zona == null) {
            return false;
        }

        zona.setNombre(nombre);
        zona.setDescripcion(descripcion);
        return true;
    }

    @Override
    //Elimina una zona del arbol
    public boolean eliminar(int codigo) {
        if (buscar(codigo) == null) {
            return false;
        }

        raiz = eliminarRecursivo(raiz, codigo);
        nNodos--;
        return true;
    }

    //Elimina recursivamente considerando los hijos del nodo
    private NodoABB eliminarRecursivo(NodoABB nodo, int codigo) {
        if (nodo == null) {
            return null;
        }

        int codigoActual = nodo.getValor().getCodigo();

        if (codigo < codigoActual) {
            nodo.setIzquierda(eliminarRecursivo(nodo.getIzquierda(), codigo));
        } else if (codigo > codigoActual) {
            nodo.setDerecha(eliminarRecursivo(nodo.getDerecha(), codigo));
        } else {
            if (nodo.getIzquierda() == null) {
                return nodo.getDerecha();
            }

            if (nodo.getDerecha() == null) {
                return nodo.getIzquierda();
            }

            NodoABB sucesor = encontrarMinimo(nodo.getDerecha());
            nodo.setValor(sucesor.getValor());
            nodo.setDerecha(eliminarRecursivo(
                    nodo.getDerecha(),
                    sucesor.getValor().getCodigo()
            ));
        }

        return nodo;
    }

    //Busca el menor elemento del subarbol derecho
    private NodoABB encontrarMinimo(NodoABB nodo) {
        NodoABB iterador = nodo;
        while (iterador.getIzquierda() != null) {
            iterador = iterador.getIzquierda();
        }
        return iterador;
    }

    @Override
    //Muestra las zonas ordenadas mediante recorrido inorden
    public String inOrden() {
        StringBuilder cadena = new StringBuilder();
        inOrdenRecursivo(raiz, cadena);
        return cadena.toString();
    }

    //Recorre izquierda, raiz y derecha
    private void inOrdenRecursivo(NodoABB nodo, StringBuilder cadena) {
        if (nodo != null) {
            inOrdenRecursivo(nodo.getIzquierda(), cadena);
            cadena.append(nodo.getValor()).append("\n");
            inOrdenRecursivo(nodo.getDerecha(), cadena);
        }
    }

    @Override
    //Muestra las zonas mediante recorrido postorden
    public String postOrden() {
        StringBuilder cadena = new StringBuilder();
        postOrdenRecursivo(raiz, cadena);
        return cadena.toString();
    }

    //Recorre izquierda, derecha y raiz
    private void postOrdenRecursivo(NodoABB nodo, StringBuilder cadena) {
        if (nodo != null) {
            postOrdenRecursivo(nodo.getIzquierda(), cadena);
            postOrdenRecursivo(nodo.getDerecha(), cadena);
            cadena.append(nodo.getValor()).append("\n");
        }
    }
}
