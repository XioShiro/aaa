package estructura;

import interfaces.InterfaceListaDoble;

/**
 * Implementación del TAD Lista Enlazada Doble.
 * Las posiciones utilizadas por sus operaciones empiezan en 1.
 *
 * @author Equipo UTP Park Manager
 */
public class ListaDoble implements InterfaceListaDoble {

    private NodoDoble inicio;
    private NodoDoble fin;
    private int nElementos;

    //Constructor de la lista enlazada doble
    public ListaDoble() {
        this.inicio = null;
        this.fin = null;
        this.nElementos = 0;
    }

    public NodoDoble getInicio() {
        return inicio;
    }

    public void setInicio(NodoDoble inicio) {
        this.inicio = inicio;
    }

    public NodoDoble getFin() {
        return fin;
    }

    public void setFin(NodoDoble fin) {
        this.fin = fin;
    }

    public int getNElementos() {
        return nElementos;
    }

    public void setNElementos(int nElementos) {
        this.nElementos = nElementos;
    }

    @Override
    //Verifica si la lista no contiene nodos
    public boolean estaVacia() {
        return inicio == null;
    }

    @Override
    //Devuelve la cantidad de elementos
    public int tamano() {
        return nElementos;
    }

    @Override
    //Inserta un nodo al inicio de la lista
    public void insertarInicio(NodoDoble nuevoNodo) {
        if (nuevoNodo == null) {
            return;
        }

        nuevoNodo.setAnterior(null);
        nuevoNodo.setSiguiente(inicio);

        if (estaVacia()) {
            fin = nuevoNodo;
        } else {
            inicio.setAnterior(nuevoNodo);
        }

        inicio = nuevoNodo;
        nElementos++;
    }

    @Override
    //Inserta un nodo al final de la lista
    public void insertarFinal(NodoDoble nuevoNodo) {
        if (nuevoNodo == null) {
            return;
        }

        nuevoNodo.setSiguiente(null);
        nuevoNodo.setAnterior(fin);

        if (estaVacia()) {
            inicio = nuevoNodo;
        } else {
            fin.setSiguiente(nuevoNodo);
        }

        fin = nuevoNodo;
        nElementos++;
    }

    @Override
    //Inserta un nodo en una posicion valida
    public boolean insertarDentro(NodoDoble nuevoNodo, int posicion) {
        if (nuevoNodo == null || posicion < 1 || posicion > nElementos + 1) {
            return false;
        }

        if (posicion == 1) {
            insertarInicio(nuevoNodo);
            return true;
        }

        if (posicion == nElementos + 1) {
            insertarFinal(nuevoNodo);
            return true;
        }

        NodoDoble actual = obtenerNodo(posicion);
        NodoDoble anterior = actual.getAnterior();

        nuevoNodo.setAnterior(anterior);
        nuevoNodo.setSiguiente(actual);
        anterior.setSiguiente(nuevoNodo);
        actual.setAnterior(nuevoNodo);
        nElementos++;
        return true;
    }

    @Override
    //Retira el primer nodo de la lista
    public Object retirarInicio() {
        if (estaVacia()) {
            return null;
        }

        NodoDoble nodoEliminar = inicio;
        inicio = inicio.getSiguiente();

        if (inicio == null) {
            fin = null;
        } else {
            inicio.setAnterior(null);
        }

        nodoEliminar.setSiguiente(null);
        nodoEliminar.setAnterior(null);
        nElementos--;
        return nodoEliminar.getElemento();
    }

    @Override
    //Retira el ultimo nodo de la lista
    public Object retirarFinal() {
        if (estaVacia()) {
            return null;
        }

        NodoDoble nodoEliminar = fin;
        fin = fin.getAnterior();

        if (fin == null) {
            inicio = null;
        } else {
            fin.setSiguiente(null);
        }

        nodoEliminar.setSiguiente(null);
        nodoEliminar.setAnterior(null);
        nElementos--;
        return nodoEliminar.getElemento();
    }

    @Override
    //Retira el nodo que se encuentra en una posicion
    public Object retirarDentro(int posicion) {
        if (posicion < 1 || posicion > nElementos) {
            return null;
        }

        if (posicion == 1) {
            return retirarInicio();
        }

        if (posicion == nElementos) {
            return retirarFinal();
        }

        NodoDoble nodoEliminar = obtenerNodo(posicion);
        nodoEliminar.getAnterior().setSiguiente(nodoEliminar.getSiguiente());
        nodoEliminar.getSiguiente().setAnterior(nodoEliminar.getAnterior());
        nodoEliminar.setAnterior(null);
        nodoEliminar.setSiguiente(null);
        nElementos--;
        return nodoEliminar.getElemento();
    }

    @Override
    //Busca un elemento y devuelve su posicion
    public int buscar(Object elemento) {
        NodoDoble iterador = inicio;
        int posicion = 1;

        while (iterador != null) {
            Object actual = iterador.getElemento();
            if ((actual == null && elemento == null)
                    || (actual != null && actual.equals(elemento))) {
                return posicion;
            }
            iterador = iterador.getSiguiente();
            posicion++;
        }

        return -1;
    }

    //Recorre la lista hasta llegar a la posicion solicitada
    private NodoDoble obtenerNodo(int posicion) {
        NodoDoble iterador;

        if (posicion <= nElementos / 2) {
            iterador = inicio;
            for (int i = 1; i < posicion; i++) {
                iterador = iterador.getSiguiente();
            }
        } else {
            iterador = fin;
            for (int i = nElementos; i > posicion; i--) {
                iterador = iterador.getAnterior();
            }
        }

        return iterador;
    }

    @Override
    //Recorre la lista desde el inicio hasta el final
    public String imprimirLista() {
        StringBuilder cadena = new StringBuilder();
        NodoDoble iterador = inicio;
        int posicion = 1;

        while (iterador != null) {
            cadena.append(posicion)
                    .append(". ")
                    .append(iterador.getElemento())
                    .append("\n");
            iterador = iterador.getSiguiente();
            posicion++;
        }

        return cadena.toString();
    }
}
