package estructura;

import interfaces.InterfaceListaCircular;

/**
 * Implementación del TAD Lista Enlazada Circular Simple.
 * El último nodo siempre apunta a la cabecera.
 *
 * @author Equipo UTP Park Manager
 */
public class ListaCircular implements InterfaceListaCircular {

    private NodoCircular cabecera;
    private int nElementos;

    //Constructor de la lista circular simple
    public ListaCircular() {
        this.cabecera = null;
        this.nElementos = 0;
    }

    public NodoCircular getCabecera() {
        return cabecera;
    }

    public void setCabecera(NodoCircular cabecera) {
        this.cabecera = cabecera;
    }

    public int getNElementos() {
        return nElementos;
    }

    public void setNElementos(int nElementos) {
        this.nElementos = nElementos;
    }

    @Override
    //Verifica si la lista circular esta vacia
    public boolean estaVacia() {
        return cabecera == null;
    }

    @Override
    //Devuelve la cantidad de vagones
    public int tamano() {
        return nElementos;
    }

    @Override
    //Inserta un vagon y hace que el ultimo apunte a la cabecera
    public void insertarFinal(NodoCircular nuevoNodo) {
        if (nuevoNodo == null) {
            return;
        }

        if (estaVacia()) {
            cabecera = nuevoNodo;
            cabecera.setSiguiente(cabecera);
        } else {
            NodoCircular ultimo = buscarUltimoNodo();
            ultimo.setSiguiente(nuevoNodo);
            nuevoNodo.setSiguiente(cabecera);
        }

        nElementos++;
    }

    @Override
    //Retira el vagon de la estacion y conserva el enlace circular
    public Object retirarInicio() {
        if (estaVacia()) {
            return null;
        }

        NodoCircular nodoEliminar = cabecera;

        if (cabecera.getSiguiente() == cabecera) {
            cabecera = null;
        } else {
            NodoCircular ultimo = buscarUltimoNodo();
            cabecera = cabecera.getSiguiente();
            ultimo.setSiguiente(cabecera);
        }

        nodoEliminar.setSiguiente(null);
        nElementos--;
        return nodoEliminar.getElemento();
    }

    //Busca el nodo cuyo siguiente apunta a la cabecera
    private NodoCircular buscarUltimoNodo() {
        if (estaVacia()) {
            return null;
        }

        NodoCircular iterador = cabecera;
        while (iterador.getSiguiente() != cabecera) {
            iterador = iterador.getSiguiente();
        }
        return iterador;
    }

    @Override
    //Recorre una vuelta completa de la lista circular
    public String imprimirCiclo() {
        if (estaVacia()) {
            return "";
        }

        StringBuilder cadena = new StringBuilder();
        NodoCircular iterador = cabecera;
        int posicion = 1;

        do {
            cadena.append(posicion)
                    .append(". Vagón ")
                    .append(iterador.getElemento())
                    .append("\n");
            iterador = iterador.getSiguiente();
            posicion++;
        } while (iterador != cabecera);

        return cadena.toString();
    }
}
