package estructura;

import modelo.Zona;

/**
 * Nodo del Árbol Binario de Búsqueda.
 *
 * @author Equipo UTP Park Manager
 */
public class NodoABB {

    private Zona valor;
    private NodoABB izquierda;
    private NodoABB derecha;

    public NodoABB() {
        this.valor = null;
        this.izquierda = null;
        this.derecha = null;
    }

    public NodoABB(Zona valor) {
        this();
        this.valor = valor;
    }

    public Zona getValor() {
        return valor;
    }

    public void setValor(Zona valor) {
        this.valor = valor;
    }

    public NodoABB getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(NodoABB izquierda) {
        this.izquierda = izquierda;
    }

    public NodoABB getDerecha() {
        return derecha;
    }

    public void setDerecha(NodoABB derecha) {
        this.derecha = derecha;
    }
}
