package estructura;

import interfaces.InterfacePila;
import modelo.Transaccion;

/**
 * Implementación del TAD Pila mediante una lista enlazada simple.
 * La cabecera representa el tope para que Push y Pop sean O(1).
 *
 * @author Equipo UTP Park Manager
 */
public class PilaTransacciones implements InterfacePila {

    private NodoPila cabecera;
    private int nElementos;

    //Constructor de la pila de transacciones
    public PilaTransacciones() {
        this.cabecera = null;
        this.nElementos = 0;
    }

    public NodoPila getCabecera() {
        return cabecera;
    }

    public void setCabecera(NodoPila cabecera) {
        this.cabecera = cabecera;
    }

    public int getNElementos() {
        return nElementos;
    }

    public void setNElementos(int nElementos) {
        this.nElementos = nElementos;
    }

    @Override
    //Verifica si la pila no contiene transacciones
    public boolean estaVacia() {
        return cabecera == null;
    }

    @Override
    //Devuelve la cantidad de transacciones apiladas
    public int tamano() {
        return nElementos;
    }

    @Override
    //Apila una transaccion en el tope
    public void push(NodoPila nuevoNodo) {
        if (nuevoNodo == null || nuevoNodo.getElemento() == null) {
            return;
        }

        nuevoNodo.setSiguiente(cabecera);
        cabecera = nuevoNodo;
        nElementos++;
    }

    @Override
    //Desapila y devuelve la ultima transaccion
    public Transaccion pop() {
        if (estaVacia()) {
            return null;
        }

        NodoPila nodoEliminar = cabecera;
        cabecera = cabecera.getSiguiente();
        nodoEliminar.setSiguiente(null);
        nElementos--;
        return nodoEliminar.getElemento();
    }

    @Override
    //Consulta la transaccion del tope sin eliminarla
    public Transaccion peek() {
        return estaVacia() ? null : cabecera.getElemento();
    }

    @Override
    //Recorre la pila desde el tope hasta el ultimo nodo
    public String imprimirPila() {
        StringBuilder cadena = new StringBuilder();
        NodoPila iterador = cabecera;

        while (iterador != null) {
            cadena.append(iterador.getElemento()).append("\n");
            iterador = iterador.getSiguiente();
        }

        return cadena.toString();
    }
}
