package estructura;

import modelo.Visitante;

/**
 * Nodo del Árbol AVL.
 *
 * @author Equipo UTP Park Manager
 */
public class NodoAVL {

    private Visitante valor;
    private NodoAVL izquierda;
    private NodoAVL derecha;
    private int altura;

    public NodoAVL() {
        this.valor = null;
        this.izquierda = null;
        this.derecha = null;
        this.altura = 0;
    }

    public NodoAVL(Visitante valor) {
        this();
        this.valor = valor;
    }

    public Visitante getValor() {
        return valor;
    }

    public void setValor(Visitante valor) {
        this.valor = valor;
    }

    public NodoAVL getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(NodoAVL izquierda) {
        this.izquierda = izquierda;
    }

    public NodoAVL getDerecha() {
        return derecha;
    }

    public void setDerecha(NodoAVL derecha) {
        this.derecha = derecha;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }
}
