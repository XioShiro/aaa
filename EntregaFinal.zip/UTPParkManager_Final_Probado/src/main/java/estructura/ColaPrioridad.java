package estructura;

import interfaces.InterfaceColaPrioridad;
import modelo.Visitante;

/**
 * Implementación del TAD Cola de Prioridad.
 * La prioridad se obtiene del tipo de pase del visitante.
 *
 * @author Equipo UTP Park Manager
 */
public class ColaPrioridad implements InterfaceColaPrioridad {

    private NodoCola cabecera;
    private int nElementos;

    //Constructor de la cola de prioridad
    public ColaPrioridad() {
        this.cabecera = null;
        this.nElementos = 0;
    }

    public NodoCola getCabecera() {
        return cabecera;
    }

    public void setCabecera(NodoCola cabecera) {
        this.cabecera = cabecera;
    }

    public int getNElementos() {
        return nElementos;
    }

    public void setNElementos(int nElementos) {
        this.nElementos = nElementos;
    }

    @Override
    //Verifica si la cola no contiene visitantes
    public boolean estaVacia() {
        return cabecera == null;
    }

    @Override
    //Devuelve la cantidad de visitantes en espera
    public int tamano() {
        return nElementos;
    }

    @Override
    //Elimina todos los nodos de la cola
    public void vaciar() {
        cabecera = null;
        nElementos = 0;
    }

    @Override
    //Encola al visitante segun su prioridad y respeta FIFO en empates
    public void enqueue(NodoCola nuevoNodo) {
        if (nuevoNodo == null || nuevoNodo.getElemento() == null) {
            return;
        }

        nuevoNodo.setSiguiente(null);
        int prioridadNueva = nuevoNodo.getElemento().obtenerPrioridad();

        if (estaVacia()
                || prioridadNueva > cabecera.getElemento().obtenerPrioridad()) {
            nuevoNodo.setSiguiente(cabecera);
            cabecera = nuevoNodo;
            nElementos++;
            return;
        }

        NodoCola iterador = cabecera;
        while (iterador.getSiguiente() != null
                && iterador.getSiguiente().getElemento().obtenerPrioridad()
                >= prioridadNueva) {
            iterador = iterador.getSiguiente();
        }

        nuevoNodo.setSiguiente(iterador.getSiguiente());
        iterador.setSiguiente(nuevoNodo);
        nElementos++;
    }

    //Metodo auxiliar para encolar directamente un visitante
    public void encolar(Visitante visitante) {
        enqueue(new NodoCola(visitante));
    }

    @Override
    //Retira al primer visitante de la cola
    public Visitante dequeue() {
        if (estaVacia()) {
            return null;
        }

        NodoCola nodoEliminar = cabecera;
        cabecera = cabecera.getSiguiente();
        nodoEliminar.setSiguiente(null);
        nElementos--;
        return nodoEliminar.getElemento();
    }

    //Metodo auxiliar que llama a dequeue
    public Visitante desencolar() {
        return dequeue();
    }

    @Override
    //Recorre la cola sin modificar su orden
    public String imprimirCola() {
        StringBuilder cadena = new StringBuilder();
        cadena.append("====================================\n");
        cadena.append("COLA DE PRIORIDAD\n");
        cadena.append("====================================");

        if (estaVacia()) {
            cadena.append("\nLA COLA ESTÁ VACÍA");
            return cadena.toString();
        }

        NodoCola iterador = cabecera;
        int posicion = 1;

        while (iterador != null) {
            Visitante visitante = iterador.getElemento();
            cadena.append("\n\nPosición    : ").append(posicion);
            cadena.append("\nBrazalete   : ").append(visitante.getCodigoBrazalete());
            cadena.append("\nNombre      : ").append(visitante.getNombre());
            cadena.append("\nTipo de pase: ").append(visitante.getTipoPase());
            cadena.append("\nPrioridad   : ").append(visitante.obtenerPrioridad());
            cadena.append("\n------------------------------------");

            iterador = iterador.getSiguiente();
            posicion++;
        }

        return cadena.toString();
    }
}
