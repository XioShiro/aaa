package interfaces;

import estructura.NodoCircular;

/**
 * TAD Lista Enlazada Circular Simple para el ciclo de vagones.
 *
 * @author Equipo UTP Park Manager
 */
public interface InterfaceListaCircular {

    public boolean estaVacia();

    public int tamano();

    public void insertarFinal(NodoCircular nuevoNodo);

    public Object retirarInicio();

    public String imprimirCiclo();
}
