package interfaces;

import estructura.NodoPila;
import modelo.Transaccion;

/**
 * TAD Pila para registrar y revertir la última transacción financiera.
 *
 * @author Equipo UTP Park Manager
 */
public interface InterfacePila {

    public boolean estaVacia();

    public int tamano();

    public void push(NodoPila nuevoNodo);

    public Transaccion pop();

    public Transaccion peek();

    public String imprimirPila();
}
