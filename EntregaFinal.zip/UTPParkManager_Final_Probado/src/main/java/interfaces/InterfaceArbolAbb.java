package interfaces;

import estructura.NodoABB;
import modelo.Zona;

/**
 * TAD Árbol Binario de Búsqueda para organizar las zonas del parque.
 *
 * @author Equipo UTP Park Manager
 */
public interface InterfaceArbolAbb {

    public boolean estaVacio();

    public void vaciar();

    public int tamano();

    public boolean insertar(Zona zona);

    public Zona buscar(int codigo);

    public boolean actualizar(int codigo, String nombre, String descripcion);

    public boolean eliminar(int codigo);

    public String inOrden();

    public String postOrden();

    public NodoABB getRaiz();
}
