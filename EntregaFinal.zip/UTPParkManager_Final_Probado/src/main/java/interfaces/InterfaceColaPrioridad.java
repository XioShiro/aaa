package interfaces;

import estructura.NodoCola;
import modelo.Visitante;

/**
 * TAD Cola de Prioridad. VIP tiene prioridad 3, FastPass 2 y Regular 1.
 * Para prioridades iguales se conserva el orden FIFO.
 *
 * @author Equipo UTP Park Manager
 */
public interface InterfaceColaPrioridad {

    public boolean estaVacia();

    public void enqueue(NodoCola nuevoNodo);

    public Visitante dequeue();

    public String imprimirCola();

    public int tamano();

    public void vaciar();
}
