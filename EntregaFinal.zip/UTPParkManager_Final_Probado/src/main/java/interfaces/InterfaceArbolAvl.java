package interfaces;

import modelo.Visitante;

/**
 * TAD Árbol AVL para administrar visitantes por código de brazalete.
 *
 * @author Equipo UTP Park Manager
 */
public interface InterfaceArbolAvl {

    public boolean estaVacio();

    public void vaciar();

    public int tamano();

    public boolean agregar(Visitante visitante);

    public Visitante buscar(int codigoBrazalete);

    public boolean eliminar(int codigoBrazalete);

    public boolean contiene(int codigoBrazalete);

    public void imprimir();

    public String mostrarVisitantes();
}
