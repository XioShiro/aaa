package interfaces;

import estructura.NodoDoble;

/**
 * TAD Lista Enlazada Doble para la fila virtual de una atracción.
 *
 * @author Equipo UTP Park Manager
 */
public interface InterfaceListaDoble {

    public boolean estaVacia();

    public int tamano();

    public void insertarInicio(NodoDoble nuevoNodo);

    public void insertarFinal(NodoDoble nuevoNodo);

    public boolean insertarDentro(NodoDoble nuevoNodo, int posicion);

    public Object retirarInicio();

    public Object retirarFinal();

    public Object retirarDentro(int posicion);

    public int buscar(Object elemento);

    public String imprimirLista();
}
