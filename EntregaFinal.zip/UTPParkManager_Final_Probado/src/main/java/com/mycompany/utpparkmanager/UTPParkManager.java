package com.mycompany.utpparkmanager;

import vista.FrmPrincipal;

/**
 * Clase principal del sistema UTP Park Manager.
 *
 * @author Equipo UTP Park Manager
 */
public class UTPParkManager {

    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel(
                    javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (Exception excepcion) {
            System.out.println("Se utilizará el estilo visual predeterminado.");
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new FrmPrincipal().setVisible(true);
            }
        });
    }
}
